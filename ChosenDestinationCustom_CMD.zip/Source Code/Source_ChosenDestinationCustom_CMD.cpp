#include <iostream>
#include <windows.h>
#include <vector>
#include <string>
#include <thread>
#include <filesystem>
#include <locale>
#include <codecvt>

namespace fs = std::filesystem;

// Function to check if a drive is ready
bool IsDriveReady(const std::wstring& drivePath) {
    DWORD driveType = GetDriveTypeW(drivePath.c_str());
    return driveType != DRIVE_NO_ROOT_DIR && driveType != DRIVE_UNKNOWN;
}

// Function to list all available drives
std::vector<std::wstring> ListDrives() {
    std::vector<std::wstring> drives;
    wchar_t szLogicalDrives[MAX_PATH] = { 0 };
    DWORD dwResult = GetLogicalDriveStringsW(MAX_PATH, szLogicalDrives);
    if (dwResult > 0 && dwResult <= MAX_PATH) {
        wchar_t* szSingleDrive = szLogicalDrives;
        while (*szSingleDrive) {
            std::wstring drivePath(1, *szSingleDrive);
            drivePath += L":\\";
            if (IsDriveReady(drivePath)) {
                drives.push_back(drivePath);
            }
            szSingleDrive += 4; // Each drive is separated by NULL character
        }
    }
    return drives;
}

// Function to copy files from source to destination
void CopyFiles(const std::wstring& sourceDir, const std::wstring& destDir) {
    for (const auto& entry : fs::directory_iterator(sourceDir)) {
        std::wcout << L"Copying " << entry.path() << L" to " << destDir << std::endl;
        fs::copy(entry.path(), destDir / entry.path().filename(), fs::copy_options::recursive);
    }
}

int main() {
    std::wcout << L"Enter the destination directory (press enter for default C:\\): ";
    std::wstring destDir;
    std::getline(std::wcin, destDir);
    if (destDir.empty()) {
        destDir = L"C:\\";
    }

    std::wcout << L"Enter the sleep interval in seconds (press enter for default 5): ";
    std::wstring sleepIntervalStr;
    std::getline(std::wcin, sleepIntervalStr);
    int sleepInterval = 5;
    if (!sleepIntervalStr.empty()) {
        sleepInterval = std::stoi(sleepIntervalStr);
    }

    std::vector<std::wstring> initialDrives = ListDrives();
    std::wcout << L"Initial drives detected: ";
    for (const auto& drive : initialDrives) {
        std::wcout << drive << L" ";
    }
    std::wcout << std::endl;

    while (true) {
        std::this_thread::sleep_for(std::chrono::seconds(sleepInterval));
        std::wcout << L"Scanning for new drives..." << std::endl;

        std::vector<std::wstring> currentDrives = ListDrives();
        for (const auto& drive : currentDrives) {
            if (std::find(initialDrives.begin(), initialDrives.end(), drive) == initialDrives.end()) {
                std::wcout << L"New drive detected: " << drive << std::endl;
                std::wstring sourceDir = drive + L"\\";
                std::wcout << L"Copying files from " << sourceDir << L" to " << destDir << std::endl;
                CopyFiles(sourceDir, destDir);
            }
        }

        initialDrives = std::move(currentDrives);
    }

    return 0;
}
